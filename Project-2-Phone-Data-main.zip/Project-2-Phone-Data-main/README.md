# Project-2-Phone-Data
Team Members: Aubrey Schelbauer - aschelba@ucsc.edu

D3 Example Inspiration:
https://www.d3-graph-gallery.com/graph/connectedscatter_legend.html

This project allows the user to interact with the data by clicking and hovering over its various elements.
